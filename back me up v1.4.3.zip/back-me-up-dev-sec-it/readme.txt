/*
    Plugin name: Back Me Up - DEV SEC IT 
    Author: DEV SEC IT Pvt. Ltd.
    Version: 1.4.3 (beta)
    Author uri: https://devsecit.com/author/webdeveloperkanai
    Description: Backup your files everyday. Follow for more   - <a href="https://devsecit.com"> DEV SEC IT Pvt. Ltd. </a>  
    Plugin uri: https://devsecit.com/plugin/back-me-up
*/

--------------------------------------------------------------------------------
Ask help on https://devsecit.com/contact
Visit our website - https://devsecit.com 
